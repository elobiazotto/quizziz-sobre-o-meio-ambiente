let perguntas = [
  {
    texto: "Por que separar o lixo ajuda o meio ambiente?",
    opcoes: ["Facilita a reciclagem e reduz poluição", "Aumenta o lixo acumulado", "Não causa nenhuma diferença"],
    resposta: 0,
    explicacao: "Separar o lixo permite que materiais recicláveis sejam reaproveitados, diminuindo a poluição e o consumo de recursos naturais."
  },
  {
    texto: "Qual é a principal causa do aquecimento global?",
    opcoes: ["Queima de combustíveis fósseis", "Uso de energia solar", "Reciclagem de papel"],
    resposta: 0,
    explicacao: "A queima de combustíveis fósseis libera gases do efeito estufa que aquecem o planeta."
  },
  {
    texto: "O que é a compostagem?",
    opcoes: ["Produção de energia solar", "Transformação de resíduos orgânicos em adubo", "Poluição da água"],
    resposta: 1,
    explicacao: "A compostagem transforma restos orgânicos em adubo natural."
  },
  {
    texto: "Qual destas ações mais economiza água?",
    opcoes: ["Deixar a torneira aberta", "Tomar banhos longos", "Reutilizar água da chuva"],
    resposta: 2,
    explicacao: "Reutilizar água da chuva é uma forma eficiente de economizar recursos hídricos."
  },
  {
    texto: "Qual gás está mais associado ao efeito estufa?",
    opcoes: ["Oxigênio", "Gás carbônico (CO₂)", "Hidrogênio"],
    resposta: 1,
    explicacao: "O gás carbônico é o principal causador do efeito estufa."
  },
  {
    texto: "O que é desmatamento?",
    opcoes: ["Plantio de árvores", "Retirada da vegetação", "Crescimento da floresta"],
    resposta: 1,
    explicacao: "Desmatamento é a retirada da vegetação, afetando o clima e a biodiversidade."
  },
  {
    texto: "Qual é uma fonte de energia renovável?",
    opcoes: ["Carvão", "Petróleo", "Energia solar"],
    resposta: 2,
    explicacao: "A energia solar é renovável, limpa e abundante."
  },
  {
    texto: "Qual item deve ir para o lixo reciclável?",
    opcoes: ["Casca de banana", "Garrafa PET", "Papel higiênico usado"],
    resposta: 1,
    explicacao: "Garrafas PET são recicláveis e devem ser descartadas corretamente."
  },
  {
    texto: "O que é biodiversidade?",
    opcoes: ["Poluição da água", "Variedade de vida", "Tipo de desmatamento"],
    resposta: 1,
    explicacao: "Biodiversidade é a variedade de seres vivos em um ambiente."
  },
  {
    texto: "Por que evitar plástico descartável?",
    opcoes: ["É barato", "É difícil de transportar", "Demora a se decompor"],
    resposta: 2,
    explicacao: "Plásticos descartáveis levam séculos para se decompor e poluem o meio ambiente."
  },
  {
    texto: "Qual é o destino correto do óleo usado?",
    opcoes: ["Pia", "Vaso sanitário", "Ponto de coleta"],
    resposta: 2,
    explicacao: "O óleo usado deve ser descartado em pontos de coleta para não poluir a água."
  },
  {
    texto: "Como o transporte público ajuda o meio ambiente?",
    opcoes: ["Aumenta trânsito", "Reduz poluição", "Gasta mais combustível"],
    resposta: 1,
    explicacao: "Usar transporte público reduz a emissão de poluentes e o número de carros nas ruas."
  },
  {
    texto: "Por que economizar energia elétrica?",
    opcoes: ["Para aquecer o planeta", "Para gastar mais", "Para reduzir impactos ambientais"],
    resposta: 2,
    explicacao: "Economizar energia reduz a queima de combustíveis e o impacto ambiental."
  },
  {
    texto: "O que são ecossistemas?",
    opcoes: ["Locais sem vida", "Ambientes com interação entre vida e meio", "Centros de reciclagem"],
    resposta: 1,
    explicacao: "Ecossistemas são ambientes onde seres vivos interagem com o meio."
  },
  {
    texto: "Como reduzir o lixo?",
    opcoes: ["Mais embalagens", "Copos descartáveis", "Menos embalagem"],
    resposta: 2,
    explicacao: "Reduzir o uso de embalagens diminui o volume de lixo gerado."
  },
  {
    texto: "O que significa reutilizar?",
    opcoes: ["Jogar fora", "Usar uma vez", "Dar nova função a algo"],
    resposta: 2,
    explicacao: "Reutilizar é dar novo uso a um material antes de descartá-lo."
  },
  {
    texto: "Por que preservar florestas?",
    opcoes: ["Só para madeira", "Produzem oxigênio", "Impedem chuva"],
    resposta: 1,
    explicacao: "Florestas ajudam a purificar o ar e manter o equilíbrio climático."
  },
  {
    texto: "Qual ação é sustentável?",
    opcoes: ["Jogar lixo na rua", "Separar o lixo", "Desperdiçar água"],
    resposta: 1,
    explicacao: "Separar o lixo contribui para reciclagem e conservação ambiental."
  },
  {
    texto: "O que é poluição sonora?",
    opcoes: ["Ruídos em excesso", "Fumaça", "Poluição da água"],
    resposta: 0,
    explicacao: "Poluição sonora é causada por sons muito altos ou contínuos."
  },
  {
    texto: "Qual material é reciclável?",
    opcoes: ["Papelão", "Papel higiênico usado", "Fraldas descartáveis"],
    resposta: 0,
    explicacao: "Papelão limpo pode ser reciclado e reaproveitado."
  },
  {
    texto: "Por que preservar rios?",
    opcoes: ["Servem ao transporte", "Fornecem água", "Poluem cidades"],
    resposta: 1,
    explicacao: "Rios são fontes de água e habitat de muitos seres vivos."
  },
  {
    texto: "O que é pegada ecológica?",
    opcoes: ["Tamanho da floresta", "Impacto do consumo humano", "Pegada de animal"],
    resposta: 1,
    explicacao: "É uma medida do quanto consumimos recursos naturais."
  },
  {
    texto: "Destino ideal para restos orgânicos?",
    opcoes: ["Lixo comum", "Reciclagem de papel", "Composteira"],
    resposta: 2,
    explicacao: "Restos de comida devem ir para a compostagem."
  },
  {
    texto: "Como economizar papel?",
    opcoes: ["Imprimir tudo", "Usar frente e verso", "Usar mais guardanapos"],
    resposta: 1,
    explicacao: "Utilizar frente e verso reduz o desperdício de papel."
  },
  {
    texto: "Impacto do lixo no oceano?",
    opcoes: ["Ajuda peixes", "Aumenta biodiversidade", "Prejudica a vida marinha"],
    resposta: 2,
    explicacao: "O lixo prejudica animais marinhos e a cadeia alimentar."
  },
  {
    texto: "O que é consumo consciente?",
    opcoes: ["Comprar sem pensar", "Pensar no impacto ambiental", "Gastar sem limites"],
    resposta: 1,
    explicacao: "Consumir com consciência ajuda a preservar o planeta."
  },
  {
    texto: "Hábito que reduz poluição do ar?",
    opcoes: ["Carro sempre", "Bicicleta", "Carro parado ligado"],
    resposta: 1,
    explicacao: "Andar de bicicleta reduz gases poluentes e melhora a saúde."
  },
  {
    texto: "O que é reciclagem?",
    opcoes: ["Queimar lixo", "Transformar resíduos", "Jogar tudo junto"],
    resposta: 1,
    explicacao: "Reciclar é transformar resíduos em novos produtos úteis."
  },
  {
    texto: "Ação contra desmatamento?",
    opcoes: ["Plantar árvores", "Comprar madeira ilegal", "Destruir matas"],
    resposta: 0,
    explicacao: "Plantar árvores compensa áreas desmatadas e preserva a natureza."
  }
];

let estado = "pergunta"; // ou "explicacao"
let perguntaAtual = 0;
let respostaSelecionada = -1;
let tempoLimite = 10;
let tempoRestante = tempoLimite;

let acertou = false;

let explicacaoTexto = "";
let explicacaoMostrada = "";
let explicacaoIndex = 0;
let tempoUltimaLetra = 0;

function setup() {
  createCanvas(800, 600);
  textAlign(CENTER, CENTER);
  textSize(20);
  setInterval(contagemRegressiva, 1000);
}

function draw() {
  if (estado === "pergunta") {
    background(100, 150, 255);
    mostrarPergunta();
  } else if (estado === "explicacao") {
    if (acertou) {
      background(100, 255, 100);
    } else {
      background(255, 100, 100);
    }
    mostrarExplicacaoAnimada();
  }
}

function mostrarPergunta() {
  let p = perguntas[perguntaAtual];
  fill(0);
  text(p.texto, width / 2, 100);

  for (let i = 0; i < p.opcoes.length; i++) {
    if (i === respostaSelecionada) {
      if (i === p.resposta) {
        fill(0, 200, 0);
      } else {
        fill(200, 0, 0);
      }
    } else {
      fill(200);
    }
    rect(width / 2 - 150, 200 + i * 80, 300, 50, 10);
    fill(0);
    text(p.opcoes[i], width / 2, 225 + i * 80);
  }

  fill(0);
  text("Tempo: " + tempoRestante, width / 2, 50);
}

function mousePressed() {
  if (estado === "pergunta") {
    for (let i = 0; i < perguntas[perguntaAtual].opcoes.length; i++) {
      if (mouseX > width / 2 - 150 && mouseX < width / 2 + 150 &&
          mouseY > 200 + i * 80 && mouseY < 250 + i * 80) {
        respostaSelecionada = i;
        acertou = (i === perguntas[perguntaAtual].resposta);
        verificarResposta();
      }
    }
  } else if (estado === "explicacao") {
    if (explicacaoMostrada.length === explicacaoTexto.length) {
      proximaPergunta();
    } else {
      explicacaoMostrada = explicacaoTexto;
    }
  }
}

function verificarResposta() {
  estado = "explicacao";
  explicacaoTexto = perguntas[perguntaAtual].explicacao;
  explicacaoMostrada = "";
  explicacaoIndex = 0;
  tempoUltimaLetra = millis();
}

function mostrarExplicacaoAnimada() {
  fill(255, 220, 200);
  ellipse(150, 400, 150, 150);
  fill(0);
  ellipse(130, 390, 10, 10);
  ellipse(170, 390, 10, 10);
  arc(150, 420, 50, 20, 0, PI);

  fill(255);
  rect(250, 150, 500, 300, 20);
  fill(0);
  textAlign(LEFT, TOP);
  textSize(18);
  text(explicacaoMostrada, 270, 170, 460, 260);

  if (millis() - tempoUltimaLetra > 30 && explicacaoIndex < explicacaoTexto.length) {
    explicacaoMostrada += explicacaoTexto[explicacaoIndex];
    explicacaoIndex++;
    tempoUltimaLetra = millis();
  }

  if (explicacaoMostrada.length === explicacaoTexto.length) {
    fill(0);
    textAlign(CENTER);
    text("Clique para continuar", width / 2, 500);
  }
}

function proximaPergunta() {
  perguntaAtual++;
  if (perguntaAtual >= perguntas.length) {
    perguntaAtual = 0;
  }
  respostaSelecionada = -1;
  tempoRestante = tempoLimite;
  estado = "pergunta";
}

function contagemRegressiva() {
  if (estado === "pergunta" && tempoRestante > 0) {
    tempoRestante--;
  } else if (estado === "pergunta" && tempoRestante <= 0) {
    acertou = false;
    estado = "explicacao";
    explicacaoTexto = "Tempo esgotado! " + perguntas[perguntaAtual].explicacao;
    explicacaoMostrada = "";
    explicacaoIndex = 0;
    tempoUltimaLetra = millis();
  }
}
